import express from "express";
import http from "http";
import { Server } from "socket.io";

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const PORT = process.env.PORT || 3000;

// Theoretical max unique 90-ball tickets is very large; use a practical high cap only to prevent infinite loops.
const MAX_BOARDS_PER_PLAYER = 1000;

const state = {
  numbers: Array.from({ length: 90 }, (_, i) => i + 1),
  drawn: [],
  players: new Map(),
  gameId: createCode(),
  showBingoButton: true,
  showLastNumberOnPlayer: true,
  lastClaim: null,
  usedBoardKeys: new Set(),
  autoDrawEnabled: false,
  autoDrawSeconds: 10,
  claimPause: null,
};

let autoDrawTimer = null;
let claimCheckTimer = null;
let claimResumeTimer = null;

function createCode() {
  return Math.random().toString(36).slice(2, 7).toUpperCase();
}

function shuffle(arr) {
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

function sample(arr, n) {
  return shuffle(arr).slice(0, n);
}

function rangeForColumn(col) {
  if (col === 0) return Array.from({ length: 9 }, (_, i) => i + 1);
  if (col === 8) return Array.from({ length: 11 }, (_, i) => i + 80);
  return Array.from({ length: 10 }, (_, i) => i + col * 10);
}

function boardKey(board) {
  return board.flat().map(cell => cell.value === null ? "x" : String(cell.value)).join("-");
}

function generateClassicBoard() {
  const rows = 3;
  const cols = 9;
  const colCounts = Array(cols).fill(1);
  let remaining = 6;

  while (remaining > 0) {
    const c = Math.floor(Math.random() * cols);
    if (colCounts[c] < 3) {
      colCounts[c] += 1;
      remaining -= 1;
    }
  }

  const columnNumbers = colCounts.map((count, col) =>
    sample(rangeForColumn(col), count).sort((a, b) => a - b)
  );

  let placements = Array.from({ length: rows }, () => Array(cols).fill(null));
  let rowCounts = Array(rows).fill(0);
  const order = [...Array(cols).keys()].sort((a, b) => colCounts[b] - colCounts[a]);

  for (const col of order) {
    const need = colCounts[col];
    let chosenRows = [...Array(rows).keys()]
      .filter(r => rowCounts[r] < 5)
      .sort((a, b) => rowCounts[a] - rowCounts[b])
      .slice(0, need);

    while (chosenRows.length < need) {
      const extra = [...Array(rows).keys()]
        .filter(r => !chosenRows.includes(r))
        .sort((a, b) => rowCounts[a] - rowCounts[b])[0];
      if (extra === undefined) break;
      chosenRows.push(extra);
    }

    chosenRows = [...new Set(chosenRows)].sort((a, b) => a - b);
    if (chosenRows.length !== need) return generateClassicBoard();

    for (let i = 0; i < need; i++) {
      const row = chosenRows[i];
      placements[row][col] = columnNumbers[col][i];
      rowCounts[row] += 1;
    }
  }

  if (rowCounts.some(c => c !== 5)) return generateClassicBoard();

  return placements.map(row =>
    row.map(value => ({
      value,
      marked: false,
    }))
  );
}

function generateUniqueBoard(maxAttempts = 2000) {
  for (let i = 0; i < maxAttempts; i++) {
    const board = generateClassicBoard();
    const key = boardKey(board);
    if (!state.usedBoardKeys.has(key)) {
      state.usedBoardKeys.add(key);
      return board;
    }
  }
  throw new Error("Kunne ikke generere en unik plade. For mange plader i samme runde.");
}

function clearUsedBoardsAndRebuildApprovedPlayers() {
  state.usedBoardKeys = new Set();
  for (const player of state.players.values()) {
    if (player.approved) player.boards = createBoards(player.boardCount);
    else player.boards = [];
  }
}

function normalizeBoardCount(count) {
  const parsed = Math.floor(Number(count) || 0);
  return Math.max(1, Math.min(MAX_BOARDS_PER_PLAYER, parsed));
}

function createBoards(count) {
  const safeCount = normalizeBoardCount(count);
  return Array.from({ length: safeCount }, () => generateUniqueBoard());
}

function evaluateBoard(board, drawn) {
  const drawnSet = new Set(drawn);
  const rowHits = board.map((row) =>
    row.filter(cell => cell.value !== null).every(cell => drawnSet.has(cell.value))
  );
  const totalNumbers = board.flat().filter(cell => cell.value !== null).map(cell => cell.value);
  const fullBoard = totalNumbers.every(n => drawnSet.has(n));
  const rowsCompleted = rowHits.filter(Boolean).length;

  return {
    rowHits,
    rowsCompleted,
    hasAnyRow: rowsCompleted >= 1,
    fullBoard,
  };
}

function evaluatePlayerBoards(player, drawn) {
  return player.boards.map((board, boardIndex) => ({
    boardIndex,
    ...evaluateBoard(board, drawn),
  }));
}

function buildClaimResult(player) {
  const boardResults = evaluatePlayerBoards(player, state.drawn);
  const anyRow = boardResults.some(r => r.hasAnyRow);
  const fullBoard = boardResults.some(r => r.fullBoard);

  return {
    playerId: player.id,
    sessionId: player.sessionId,
    name: player.name,
    time: new Date().toLocaleTimeString("da-DK"),
    drawnCount: state.drawn.length,
    boardResults,
    anyRow,
    fullBoard,
    valid: anyRow || fullBoard,
  };
}

function publicPlayers() {
  return [...state.players.values()].map(player => ({
    id: player.id,
    sessionId: player.sessionId,
    name: player.name,
    boardCount: player.boardCount,
    approved: player.approved,
  }));
}

function emitState() {
  const remainingCount = state.numbers.filter((n) => !state.drawn.includes(n)).length;

  io.emit("state:update", {
    gameId: state.gameId,
    drawn: state.drawn,
    lastNumber: state.drawn[state.drawn.length - 1] || null,
    remaining: remainingCount,
    playerCount: state.players.size,
    showBingoButton: state.showBingoButton,
    showLastNumberOnPlayer: state.showLastNumberOnPlayer,
    lastClaim: state.lastClaim,
    autoDrawEnabled: state.autoDrawEnabled,
    autoDrawSeconds: state.autoDrawSeconds,
    claimPause: state.claimPause,
    players: publicPlayers(),
  });

  for (const [socketId, player] of state.players.entries()) {
    io.to(socketId).emit("player:boards", {
      sessionId: player.sessionId,
      boards: player.boards,
      boardCount: player.boardCount,
      approved: player.approved,
      lastNumber: state.drawn[state.drawn.length - 1] || null,
      showBingoButton: state.showBingoButton,
      showLastNumberOnPlayer: state.showLastNumberOnPlayer,
    });
  }
}

function drawNext() {
  const remaining = state.numbers.filter((n) => !state.drawn.includes(n));
  if (remaining.length === 0) return null;
  const next = remaining[Math.floor(Math.random() * remaining.length)];
  state.drawn.push(next);
  emitState();
  return next;
}

function normalizeAutoDrawSeconds(seconds) {
  const parsed = Math.floor(Number(seconds) || 10);
  return parsed === 20 ? 20 : 10;
}

function stopAutoDraw(emit = true) {
  if (autoDrawTimer) {
    clearInterval(autoDrawTimer);
    autoDrawTimer = null;
  }
  state.autoDrawEnabled = false;
  if (emit) emitState();
}

function startAutoDraw(seconds) {
  const safeSeconds = normalizeAutoDrawSeconds(seconds);
  if (autoDrawTimer) clearInterval(autoDrawTimer);

  state.autoDrawSeconds = safeSeconds;
  state.autoDrawEnabled = true;
  autoDrawTimer = setInterval(() => {
    const next = drawNext();
    if (next === null) stopAutoDraw();
  }, safeSeconds * 1000);
  emitState();
}

function clearClaimTimers() {
  if (claimCheckTimer) {
    clearTimeout(claimCheckTimer);
    claimCheckTimer = null;
  }
  if (claimResumeTimer) {
    clearTimeout(claimResumeTimer);
    claimResumeTimer = null;
  }
}

function finishInvalidClaimCountdown(resumeAutoDraw, resumeSeconds) {
  claimResumeTimer = setTimeout(() => {
    claimResumeTimer = null;
    state.claimPause = null;

    // Efter en forkert BANKO-melding trækkes næste tal automatisk,
    // også hvis værten ellers trak manuelt.
    const next = drawNext();
    if (next === null) {
      stopAutoDraw();
      return;
    }

    // Hvis auto-træk kørte før BANKO blev meldt, fortsætter det
    // med samme interval efter det første nye tal.
    if (resumeAutoDraw) startAutoDraw(resumeSeconds);
  }, 10_000);
}

function beginBingoCheck(player) {
  if (state.claimPause) return;

  const resumeAutoDraw = state.autoDrawEnabled;
  const resumeSeconds = state.autoDrawSeconds;
  stopAutoDraw(false);
  clearClaimTimers();

  state.claimPause = {
    status: "checking",
    name: player.name,
    startedAt: Date.now(),
    endsAt: null,
  };
  emitState();

  // En kort synlig kontrolpause gør det tydeligt på alle spillertelefoner,
  // at systemet rent faktisk kontrollerer meldingen.
  claimCheckTimer = setTimeout(() => {
    claimCheckTimer = null;
    const currentPlayer = findPlayerBySessionId(player.sessionId) || player;
    const claim = buildClaimResult(currentPlayer);
    state.lastClaim = claim;
    io.emit("bingo:claim", claim);

    if (claim.valid) {
      state.claimPause = {
        status: "valid",
        name: claim.name,
        startedAt: Date.now(),
        endsAt: null,
      };
      emitState();
      return;
    }

    const endsAt = Date.now() + 10_000;
    state.claimPause = {
      status: "invalid",
      name: claim.name,
      startedAt: Date.now(),
      endsAt,
    };
    emitState();
    finishInvalidClaimCountdown(resumeAutoDraw, resumeSeconds);
  }, 700);
}

function resetGame() {
  stopAutoDraw(false);
  clearClaimTimers();
  state.drawn = [];
  state.gameId = createCode();
  state.lastClaim = null;
  state.claimPause = null;
  clearUsedBoardsAndRebuildApprovedPlayers();
  emitState();
}

function findPlayerBySessionId(sessionId) {
  for (const player of state.players.values()) {
    if (player.sessionId === sessionId) return player;
  }
  return null;
}

io.on("connection", (socket) => {
  socket.on("player:join", ({ name, sessionId }) => {
    const safeName = (name || "Spiller").toString().trim().slice(0, 30) || "Spiller";
    const safeSessionId = (sessionId || "").toString().trim() || Math.random().toString(36).slice(2);

    const existing = findPlayerBySessionId(safeSessionId);
    if (existing) {
      state.players.delete(existing.id);
      existing.id = socket.id;
      existing.name = safeName || existing.name;
      state.players.set(socket.id, existing);
      emitState();
      return;
    }

    state.players.set(socket.id, {
      id: socket.id,
      sessionId: safeSessionId,
      name: safeName,
      boardCount: 0,
      approved: false,
      boards: [],
    });
    emitState();
  });

  socket.on("player:resume", ({ sessionId }) => {
    const existing = findPlayerBySessionId((sessionId || "").toString().trim());
    if (!existing) {
      io.to(socket.id).emit("player:resume_failed");
      return;
    }
    state.players.delete(existing.id);
    existing.id = socket.id;
    state.players.set(socket.id, existing);
    emitState();
  });

  socket.on("host:draw", () => {
    if (state.claimPause) return;
    drawNext();
  });
  socket.on("host:reset", () => resetGame());
  socket.on("host:setAutoDraw", ({ enabled, seconds }) => {
    if (state.claimPause && enabled) return;
    if (enabled) startAutoDraw(seconds);
    else stopAutoDraw();
  });

  socket.on("host:setBoardCount", ({ playerId, boardCount }) => {
    const player = state.players.get(playerId);
    if (!player) return;
    const safeCount = normalizeBoardCount(boardCount);

    for (const board of player.boards || []) {
      state.usedBoardKeys.delete(boardKey(board));
    }

    player.boardCount = safeCount;
    player.approved = true;
    player.boards = createBoards(safeCount);
    emitState();
  });

  socket.on("host:setUiOptions", ({ showBingoButton, showLastNumberOnPlayer }) => {
    state.showBingoButton = !!showBingoButton;
    state.showLastNumberOnPlayer = !!showLastNumberOnPlayer;
    emitState();
  });

  socket.on("player:toggleMark", ({ boardIndex, row, col }) => {
    const player = state.players.get(socket.id);
    if (!player || !player.approved) return;
    const cell = player.boards?.[boardIndex]?.[row]?.[col];
    if (!cell || cell.value === null) return;
    cell.marked = !cell.marked;
    emitState();
  });

  socket.on("player:bingo", () => {
    const player = state.players.get(socket.id);
    if (!player || !player.approved) return;
    beginBingoCheck(player);
  });
});

app.get("/", (_req, res) => res.send(html()));
app.get("/health", (_req, res) => res.json({ ok: true, players: state.players.size, drawn: state.drawn.length }));

server.listen(PORT, "0.0.0.0", () => {
  console.log("Pubbanko kører på http://0.0.0.0:" + PORT);
});

function html() {
  return `<!doctype html>
  <html lang="da">
    <head>
      <meta charset="UTF-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <title>Banko</title>
      <script src="/socket.io/socket.io.js"></script>
      <style>
        :root { --text:#111111; --paper:#f7f4ec; --line:#555; --accent:#f59e0b; --good:#22c55e; --danger:#c0392b; }
        * { box-sizing:border-box; }
        body { margin:0; font-family:Arial, Helvetica, sans-serif; background:#1f2937; color:white; min-height:100vh; }
        .wrap { max-width:1320px; margin:0 auto; padding:18px; }
        .hero, .panel { background:rgba(255,255,255,0.08); border-radius:18px; padding:16px; margin-bottom:16px; box-shadow:0 8px 24px rgba(0,0,0,0.2); }
        .hero.player-hero { min-height:38vh; display:grid; place-items:center; text-align:center; }
        .hero.player-hero h1 { font-size:clamp(42px, 10vw, 84px); margin:0 0 20px; }
        .login-box { width:100%; max-width:420px; margin:0 auto; }
        .muted { color:rgba(255,255,255,0.8); }
        .pill { display:inline-block; padding:8px 12px; border-radius:999px; background:rgba(255,255,255,0.12); margin-right:8px; margin-bottom:8px; font-size:14px; }
        .grid { display:grid; gap:16px; }
        @media (min-width:1080px) { .grid { grid-template-columns: 1.05fr 0.95fr; } }
        input, button, select { width:100%; border:none; border-radius:12px; padding:14px 16px; font-size:16px; }
        input, select { margin-bottom:12px; }
        button { background:var(--accent); color:#111; font-weight:700; cursor:pointer; margin-bottom:10px; }
        button.good { background:var(--good); color:#052; }
        button.danger { background:var(--danger); color:white; }
        .hidden { display:none !important; }
        .number { display:grid; place-items:center; min-height:150px; font-size:clamp(42px, 10vw, 86px); font-weight:900; border-radius:20px; background:radial-gradient(circle at top, #fbbf24, #f59e0b); color:#111827; margin-bottom:12px; }
        .last-number-player { display:grid; place-items:center; min-height:110px; font-size:clamp(34px, 9vw, 72px); font-weight:900; border-radius:18px; background:radial-gradient(circle at top, #fbbf24, #f59e0b); color:#111827; margin-bottom:12px; }
        .stats { display:grid; grid-template-columns:repeat(3, 1fr); gap:10px; margin:12px 0 16px; }
        .stat { background:rgba(255,255,255,0.08); border-radius:14px; padding:12px; text-align:center; }
        .stat strong { display:block; font-size:24px; margin-top:4px; }
        .board-wrap { background:var(--paper); border-radius:10px; padding:6px; border:3px solid #222; color:#111; margin-bottom:12px; }
        .board { display:grid; gap:0; border:2px solid #444; background:white; }
        .player-row-grid { display:grid; grid-template-columns:repeat(9, 1fr); }
        .checker-grid { display:grid; grid-template-columns:repeat(9, 1fr); }
        .cell { border-right:1px solid var(--line); border-bottom:1px solid var(--line); aspect-ratio:1.35 / 1; min-height:50px; display:flex; align-items:center; justify-content:center; background:#fdfcf8; position:relative; user-select:none; }
        .checker-cell { border-right:1px solid var(--line); border-bottom:1px solid var(--line); aspect-ratio:1 / 1; min-height:42px; display:flex; align-items:center; justify-content:center; background:#fdfcf8; color:#222; font-weight:700; font-size:16px; }
        .checker-cell.marked { background:#d7f4da; color:#14532d; }
        .checker-cell.blank { background:#ece8dd; }
        .player-row-grid:last-child .cell { border-bottom:none; }
        .cell:last-child, .checker-cell:nth-child(9n) { border-right:none; }
        .cell.blank { background:linear-gradient(180deg, rgba(0,0,0,0.03), rgba(0,0,0,0.01)); }
        .cell.number-cell { cursor:pointer; font-size:clamp(18px, 5vw, 28px); font-weight:800; color:#222; }
        .cell.number-cell.marked { background:#d7f4da; }
        .cell.number-cell.marked::after { content:"✓"; position:absolute; top:4px; right:6px; font-size:14px; color:#1f7a3d; font-weight:700; }
        .drawn-list { line-height:2; }
        .drawn-pill { display:inline-block; min-width:36px; text-align:center; padding:6px 8px; margin:0 6px 6px 0; border-radius:999px; background:rgba(255,255,255,0.14); font-weight:700; }
        .drawn-pill.latest { background:#f59e0b; color:#111; }
        .claim { padding:12px; border-radius:12px; background:rgba(34,197,94,0.2); border:1px solid rgba(34,197,94,0.5); margin-top:10px; }
        .claim.bad { background:rgba(192,57,43,0.2); border-color:rgba(192,57,43,0.6); }
        .claim.info { background:rgba(37,99,235,0.2); border-color:rgba(37,99,235,0.6); }
        .bingo-notice { position:fixed; inset:0; z-index:9999; display:grid; place-items:center; padding:22px; background:rgba(5,12,18,0.90); backdrop-filter:blur(4px); }
        .bingo-notice-card { width:min(92vw,560px); text-align:center; border-radius:24px; padding:28px 20px; background:#f7f4ec; color:#151515; box-shadow:0 18px 60px rgba(0,0,0,.45); border:4px solid #f59e0b; }
        .bingo-notice-card.invalid { border-color:#c0392b; }
        .bingo-notice-card.valid { border-color:#22c55e; }
        .bingo-notice-title { margin:0 0 12px; font-size:clamp(30px,8vw,52px); line-height:1.05; font-weight:900; }
        .bingo-notice-text { margin:0; font-size:clamp(17px,4.2vw,23px); line-height:1.4; }
        .bingo-countdown-label { margin-top:22px; font-size:18px; font-weight:800; }
        .bingo-countdown { display:grid; place-items:center; width:128px; height:128px; margin:10px auto 0; border-radius:50%; background:#c0392b; color:white; font-size:64px; font-weight:900; box-shadow:0 8px 22px rgba(0,0,0,.25); }
        .player-admin { display:grid; gap:10px; }
        .player-row { display:grid; grid-template-columns:1.5fr 140px 130px; gap:10px; align-items:center; background:rgba(255,255,255,0.08); padding:10px; border-radius:12px; }
        .player-name { font-weight:700; }
        .small-input { margin:0; padding:10px 12px; }
        .waiting { min-height:60vh; display:grid; place-items:center; text-align:center; padding:24px; }
        .waiting-card { background:rgba(255,255,255,0.08); border-radius:20px; padding:30px 20px; width:100%; max-width:540px; box-shadow:0 8px 24px rgba(0,0,0,0.2); }
        .waiting-card h2 { margin:0 0 12px; font-size:clamp(28px, 6vw, 42px); }
        .waiting-card p { margin:0; color:rgba(255,255,255,0.82); font-size:clamp(16px, 3vw, 20px); }
        .player-clean { max-width:950px; margin:0 auto; padding:12px; }
        .boards-only { display:grid; gap:12px; }
        .top-actions { display:flex; gap:10px; margin-bottom:8px; }
        .top-actions button { margin-bottom:0; }
        .toggle-box, .calc-box { background:rgba(255,255,255,0.08); border-radius:12px; padding:12px; margin-bottom:12px; }
        .toggle-row { display:flex; align-items:center; justify-content:space-between; gap:12px; padding:8px 0; }
        .toggle-row label { font-weight:700; }
        .toggle-row input[type="checkbox"] { width:24px; height:24px; margin:0; }
        .checker-title { margin:0 0 10px; font-weight:700; color:#111; }
        .result-list { margin-top:8px; font-size:14px; line-height:1.5; }
        .result-item { padding:4px 0; border-top:1px solid rgba(255,255,255,0.12); }
        .calc-grid { display:grid; grid-template-columns:repeat(2, 1fr); gap:10px; }
        .calc-output { display:grid; grid-template-columns:repeat(2, 1fr); gap:10px; margin-top:8px; }
        .calc-stat { background:rgba(255,255,255,0.08); border-radius:12px; padding:10px; }
        .calc-stat small { display:block; color:rgba(255,255,255,0.75); }
        .calc-stat strong { display:block; font-size:22px; margin-top:4px; }
        .calc-note { color:rgba(255,255,255,0.82); font-size:13px; line-height:1.5; margin-top:8px; }
        @media (max-width:640px) { .player-row, .calc-grid, .calc-output { grid-template-columns:1fr; } .top-actions { flex-direction:column; } .checker-cell { min-height:34px; font-size:13px; } }
      </style>
    </head>
    <body>
      <div class="wrap" id="appWrap">
        <div class="hero player-hero" id="playerLanding">
          <div class="login-box">
            <h1>Banko</h1>
            <div id="joinBox">
              <input id="nameInput" placeholder="Login" maxlength="30" />
              <button id="joinBtn">Login</button>
            </div>
          </div>
        </div>

        <div class="hero hidden" id="heroBox">
          <h1>🍻 Pubbanko</h1>
          <p class="muted">Ingen fast begrænsning på antal spillere. Antal plader pr. spiller er hævet kraftigt, men meget høje tal vil naturligt gøre systemet tungere.</p>
          <span class="pill">Host: http://DIN-IP:${PORT}/?host=1</span>
        </div>

        <div class="grid hidden" id="mainGrid">
          <section class="panel" id="playerView">
            <div id="waitingBox" class="hidden waiting">
              <div class="waiting-card">
                <h2>Venter på bartender…</h2>
                <p>Dine plader bliver vist her, så snart bartenderen har godkendt og valgt antal plader.</p>
              </div>
            </div>

            <div id="playerBox" class="hidden player-clean">
              <div id="lastNumberPlayerBox" class="last-number-player hidden">-</div>
              <div class="top-actions">
                <button class="good" id="bingoBtn">BANKO!</button>
              </div>
              <div class="boards-only" id="boardsContainer"></div>
            </div>

            <div id="claimBox"></div>
          </section>

          <section class="panel" id="hostView">
            <h2>Vært</h2>
            <div class="claim info" style="margin:0 0 14px">
              <strong>⚠️ Regler før Banko startes</strong><br>
              Denne version er til test. Slå ikke betaling eller præmier til, før den konkrete Banko-model og de nødvendige tilladelser er afklaret. Bartenderen er ansvarlig for kun at starte Banko efter pubbens gældende regler og instruktioner.
            </div>
            <div class="number" id="lastNumber">-</div>

            <div class="stats">
              <div class="stat"><span>Trukket</span><strong id="drawnCount">0</strong></div>
              <div class="stat"><span>Tilbage</span><strong id="remainingCount">90</strong></div>
              <div class="stat"><span>Spillere</span><strong id="playerCount">0</strong></div>
            </div>

            <button id="drawBtn">Træk næste nummer</button>

            <div class="toggle-box" style="margin-top:10px">
              <div class="toggle-row" style="gap:10px;align-items:center">
                <label for="autoDrawSeconds">Auto-træk</label>
                <select id="autoDrawSeconds" style="max-width:170px">
                  <option value="10">Hvert 10. sekund</option>
                  <option value="20">Hvert 20. sekund</option>
                </select>
              </div>
              <button id="autoDrawBtn" type="button">Start auto-træk</button>
              <div id="autoDrawStatus" class="muted" style="margin-top:8px">Auto-træk er slået fra</div>
            </div>

            <button class="danger" id="resetBtn">Nulstil spil</button>

            <div class="toggle-box">
              <div class="toggle-row">
                <label for="toggleBingo">Vis BANKO-knap hos spiller</label>
                <input id="toggleBingo" type="checkbox" checked />
              </div>
              <div class="toggle-row">
                <label for="toggleLastNumber">Vis senest trukne nummer hos spiller</label>
                <input id="toggleLastNumber" type="checkbox" checked />
              </div>
            </div>

            <div class="calc-box">
              <h3 style="margin-top:0">Præmieberegner</h3>
              <div class="calc-grid">
                <div>
                  <label>Pris pr. plade</label>
                  <input id="pricePerBoard" type="number" min="0" step="1" value="25" />
                </div>
                <div>
                  <label>Antal spil</label>
                  <input id="gameCount" type="number" min="1" step="1" value="10" />
                </div>
                <div>
                  <label>Præmiepulje (%)</label>
                  <input id="payoutPercent" type="number" min="1" max="100" step="1" value="100" />
                </div>
                <div>
                  <label>Fordeling</label>
                  <select id="prizeMode">
                    <option value="two_30_70">2 præmier: 30% linje / 70% fuld plade</option>
                    <option value="two_25_75">2 præmier: 25% linje / 75% fuld plade</option>
                    <option value="three_175_325_500">3 præmier: 17,5% / 32,5% / 50%</option>
                  </select>
                </div>
              </div>

              <div class="calc-output">
                <div class="calc-stat"><small>Solgte plader pr. spil</small><strong id="soldBoardsOut">0</strong></div>
                <div class="calc-stat"><small>Omsætning pr. spil</small><strong id="revenuePerGameOut">0 kr</strong></div>
                <div class="calc-stat"><small>Linje-præmie pr. spil</small><strong id="linePrizeOut">0 kr</strong></div>
                <div class="calc-stat"><small>Fuld plade-præmie pr. spil</small><strong id="fullPrizeOut">0 kr</strong></div>
              </div>

              <div class="calc-output" id="twoLineRow">
                <div class="calc-stat"><small>2 linjer-præmie pr. spil</small><strong id="twoLinePrizeOut">0 kr</strong></div>
                <div class="calc-stat"><small>Samlet præmiepulje pr. spil</small><strong id="prizePoolPerGameOut">0 kr</strong></div>
              </div>

              <div class="calc-output">
                <div class="calc-stat"><small>Samlet omsætning i alt</small><strong id="totalRevenueOut">0 kr</strong></div>
                <div class="calc-stat"><small>Samlet præmiepulje i alt</small><strong id="totalPrizePoolOut">0 kr</strong></div>
              </div>
            </div>

            <div class="board-wrap">
              <div class="checker-title">Opråber-plade over trukne numre</div>
              <div class="checker-grid" id="hostCheckerGrid"></div>
            </div>

            <div id="hostClaimBox"></div>

            <div style="margin-top:12px">
              <h3>Spillere og købte plader</h3>
              <div class="player-admin" id="playerAdminList"></div>
            </div>

            <div style="margin-top:12px">
              <h3>Trukne numre</h3>
              <div class="drawn-list" id="drawnList"></div>
            </div>
          </section>
        </div>
      </div>

      <div class="bingo-notice hidden" id="bingoNotice" aria-live="assertive">
        <div class="bingo-notice-card" id="bingoNoticeCard">
          <h2 class="bingo-notice-title" id="bingoNoticeTitle">BANKO KALDT</h2>
          <p class="bingo-notice-text" id="bingoNoticeText">Systemet kontrollerer pladerne…</p>
          <div class="hidden" id="bingoCountdownWrap">
            <div class="bingo-countdown-label">Næste tal trækkes om</div>
            <div class="bingo-countdown" id="bingoCountdown">10</div>
          </div>
        </div>
      </div>

      <script>
        const socket = io({ reconnection: true, reconnectionAttempts: Infinity, reconnectionDelay: 500, reconnectionDelayMax: 3000 });
        const params = new URLSearchParams(window.location.search);
        const isHost = params.get("host") === "1";

        let currentPlayers = [];
        let currentSessionId = localStorage.getItem("pubbanko_session_id");
        if (!currentSessionId) {
          currentSessionId = Math.random().toString(36).slice(2) + Date.now().toString(36);
          localStorage.setItem("pubbanko_session_id", currentSessionId);
        }

        const els = {
          playerLanding: document.getElementById("playerLanding"),
          heroBox: document.getElementById("heroBox"),
          mainGrid: document.getElementById("mainGrid"),
          playerView: document.getElementById("playerView"),
          waitingBox: document.getElementById("waitingBox"),
          playerBox: document.getElementById("playerBox"),
          nameInput: document.getElementById("nameInput"),
          joinBtn: document.getElementById("joinBtn"),
          boardsContainer: document.getElementById("boardsContainer"),
          bingoBtn: document.getElementById("bingoBtn"),
          lastNumberPlayerBox: document.getElementById("lastNumberPlayerBox"),
          claimBox: document.getElementById("claimBox"),
          hostClaimBox: document.getElementById("hostClaimBox"),
          bingoNotice: document.getElementById("bingoNotice"),
          bingoNoticeCard: document.getElementById("bingoNoticeCard"),
          bingoNoticeTitle: document.getElementById("bingoNoticeTitle"),
          bingoNoticeText: document.getElementById("bingoNoticeText"),
          bingoCountdownWrap: document.getElementById("bingoCountdownWrap"),
          bingoCountdown: document.getElementById("bingoCountdown"),
          hostView: document.getElementById("hostView"),
          lastNumber: document.getElementById("lastNumber"),
          drawnCount: document.getElementById("drawnCount"),
          remainingCount: document.getElementById("remainingCount"),
          playerCount: document.getElementById("playerCount"),
          drawBtn: document.getElementById("drawBtn"),
          autoDrawSeconds: document.getElementById("autoDrawSeconds"),
          autoDrawBtn: document.getElementById("autoDrawBtn"),
          autoDrawStatus: document.getElementById("autoDrawStatus"),
          resetBtn: document.getElementById("resetBtn"),
          drawnList: document.getElementById("drawnList"),
          playerAdminList: document.getElementById("playerAdminList"),
          toggleBingo: document.getElementById("toggleBingo"),
          toggleLastNumber: document.getElementById("toggleLastNumber"),
          hostCheckerGrid: document.getElementById("hostCheckerGrid"),
          pricePerBoard: document.getElementById("pricePerBoard"),
          gameCount: document.getElementById("gameCount"),
          payoutPercent: document.getElementById("payoutPercent"),
          prizeMode: document.getElementById("prizeMode"),
          soldBoardsOut: document.getElementById("soldBoardsOut"),
          revenuePerGameOut: document.getElementById("revenuePerGameOut"),
          linePrizeOut: document.getElementById("linePrizeOut"),
          fullPrizeOut: document.getElementById("fullPrizeOut"),
          twoLinePrizeOut: document.getElementById("twoLinePrizeOut"),
          prizePoolPerGameOut: document.getElementById("prizePoolPerGameOut"),
          totalRevenueOut: document.getElementById("totalRevenueOut"),
          totalPrizePoolOut: document.getElementById("totalPrizePoolOut"),
          twoLineRow: document.getElementById("twoLineRow"),
        };

        function money(v) { return Math.round(v).toLocaleString("da-DK") + " kr"; }
        function soldBoardsCount() { return (currentPlayers || []).filter(p => p.approved).reduce((sum, p) => sum + (Number(p.boardCount) || 0), 0); }

        function recalcPrizeCalculator() {
          const soldBoards = soldBoardsCount();
          const pricePerBoard = Math.max(0, Number(els.pricePerBoard.value) || 0);
          const gameCount = Math.max(1, Number(els.gameCount.value) || 1);
          const payoutPercent = Math.max(1, Math.min(100, Number(els.payoutPercent.value) || 100));
          const mode = els.prizeMode.value;

          const revenuePerGame = soldBoards * pricePerBoard;
          const prizePoolPerGame = revenuePerGame * (payoutPercent / 100);

          let line = 0, twoLines = 0, full = 0;
          if (mode === "two_30_70") {
            line = prizePoolPerGame * 0.30;
            full = prizePoolPerGame * 0.70;
            els.twoLineRow.classList.add("hidden");
          } else if (mode === "two_25_75") {
            line = prizePoolPerGame * 0.25;
            full = prizePoolPerGame * 0.75;
            els.twoLineRow.classList.add("hidden");
          } else {
            line = prizePoolPerGame * 0.175;
            twoLines = prizePoolPerGame * 0.325;
            full = prizePoolPerGame * 0.50;
            els.twoLineRow.classList.remove("hidden");
          }

          els.soldBoardsOut.textContent = soldBoards;
          els.revenuePerGameOut.textContent = money(revenuePerGame);
          els.linePrizeOut.textContent = money(line);
          els.fullPrizeOut.textContent = money(full);
          els.twoLinePrizeOut.textContent = money(twoLines);
          els.prizePoolPerGameOut.textContent = money(prizePoolPerGame);
          els.totalRevenueOut.textContent = money(revenuePerGame * gameCount);
          els.totalPrizePoolOut.textContent = money(prizePoolPerGame * gameCount);
        }

        [els.pricePerBoard, els.gameCount, els.payoutPercent, els.prizeMode].forEach(el => {
          el?.addEventListener("input", recalcPrizeCalculator);
          el?.addEventListener("change", recalcPrizeCalculator);
        });

        function showHostMode() {
          els.playerLanding.classList.add("hidden");
          els.heroBox.classList.remove("hidden");
          els.mainGrid.classList.remove("hidden");
          els.waitingBox.classList.add("hidden");
          els.playerBox.classList.add("hidden");
        }

        function showWaitingMode() {
          els.playerLanding.classList.add("hidden");
          els.mainGrid.classList.remove("hidden");
          els.playerView.classList.remove("hidden");
          els.waitingBox.classList.remove("hidden");
          els.playerBox.classList.add("hidden");
          els.hostView.classList.add("hidden");
        }

        if (isHost) showHostMode();
        else { els.heroBox.classList.add("hidden"); els.mainGrid.classList.add("hidden"); els.hostView.classList.add("hidden"); }

        function sendUiOptions() {
          socket.emit("host:setUiOptions", {
            showBingoButton: els.toggleBingo.checked,
            showLastNumberOnPlayer: els.toggleLastNumber.checked
          });
        }

        els.toggleBingo?.addEventListener("change", sendUiOptions);
        els.toggleLastNumber?.addEventListener("change", sendUiOptions);

        els.joinBtn?.addEventListener("click", () => {
          const name = els.nameInput.value.trim() || "Spiller";
          localStorage.setItem("pubbanko_name", name);
          socket.emit("player:join", { name, sessionId: currentSessionId });
          showWaitingMode();
        });

        socket.on("connect", () => {
          if (isHost) return;
          const savedName = localStorage.getItem("pubbanko_name");
          if (savedName) socket.emit("player:resume", { sessionId: currentSessionId });
        });

        document.addEventListener("visibilitychange", () => {
          if (!isHost && document.visibilityState === "visible") {
            const savedName = localStorage.getItem("pubbanko_name");
            if (savedName) socket.emit("player:resume", { sessionId: currentSessionId });
          }
        });

        window.addEventListener("focus", () => {
          if (!isHost) {
            const savedName = localStorage.getItem("pubbanko_name");
            if (savedName) socket.emit("player:resume", { sessionId: currentSessionId });
          }
        });

        els.bingoBtn?.addEventListener("click", () => socket.emit("player:bingo"));
        els.drawBtn?.addEventListener("click", () => socket.emit("host:draw"));
        els.autoDrawBtn?.addEventListener("click", () => {
          const running = els.autoDrawBtn.dataset.running === "1";
          socket.emit("host:setAutoDraw", {
            enabled: !running,
            seconds: Number(els.autoDrawSeconds.value) || 10
          });
        });
        els.autoDrawSeconds?.addEventListener("change", () => {
          if (els.autoDrawBtn.dataset.running === "1") {
            socket.emit("host:setAutoDraw", {
              enabled: true,
              seconds: Number(els.autoDrawSeconds.value) || 10
            });
          }
        });
        els.resetBtn?.addEventListener("click", () => {
          if (confirm("Nulstil spil og giv nye plader til alle godkendte spillere?")) socket.emit("host:reset");
        });

        function renderOneBoard(board, boardIndex) {
          const wrap = document.createElement("div");
          wrap.className = "board-wrap";
          const boardEl = document.createElement("div");
          boardEl.className = "board";

          board.forEach((row, rowIndex) => {
            const rowEl = document.createElement("div");
            rowEl.className = "player-row-grid";
            row.forEach((cell, colIndex) => {
              const cellEl = document.createElement("div");
              if (cell.value === null) {
                cellEl.className = "cell blank";
              } else {
                cellEl.className = "cell number-cell" + (cell.marked ? " marked" : "");
                cellEl.textContent = cell.value;
                cellEl.addEventListener("click", () => {
                  socket.emit("player:toggleMark", { boardIndex, row: rowIndex, col: colIndex });
                });
              }
              rowEl.appendChild(cellEl);
            });
            boardEl.appendChild(rowEl);
          });

          wrap.appendChild(boardEl);
          return wrap;
        }

        function renderBoards(boards) {
          els.boardsContainer.innerHTML = "";
          boards.forEach((board, boardIndex) => {
            els.boardsContainer.appendChild(renderOneBoard(board, boardIndex));
          });
        }

        function renderPlayerAdmin(players) {
          currentPlayers = players || [];
          els.playerAdminList.innerHTML = "";
          if (!players.length) {
            els.playerAdminList.innerHTML = '<div class="muted">Ingen spillere logget ind endnu.</div>';
            recalcPrizeCalculator();
            return;
          }

          players.forEach((player) => {
            const row = document.createElement("div");
            row.className = "player-row";

            const name = document.createElement("div");
            name.className = "player-name";
            name.textContent = player.name + (player.approved ? " ✅" : " ⏳");

            const input = document.createElement("input");
            input.type = "number";
            input.min = "1";
            input.step = "1";
            input.value = player.boardCount || 1;
            input.className = "small-input";

            const btn = document.createElement("button");
            btn.textContent = player.approved ? "Opdater plader" : "Godkend plader";
            btn.addEventListener("click", () => {
              socket.emit("host:setBoardCount", { playerId: player.id, boardCount: input.value });
            });

            row.appendChild(name);
            row.appendChild(input);
            row.appendChild(btn);
            els.playerAdminList.appendChild(row);
          });

          recalcPrizeCalculator();
        }

        function renderHostChecker(drawn) {
          const drawnSet = new Set(drawn || []);
          els.hostCheckerGrid.innerHTML = "";
          for (let row = 0; row < 11; row++) {
            for (let col = 0; col < 9; col++) {
              const cell = document.createElement("div");
              let value = null;
              if (col === 0) value = row < 9 ? row + 1 : null;
              else if (col === 8) value = row < 11 ? row + 80 : null;
              else value = row < 10 ? (col * 10) + row : null;

              if (value === null || value > 90) {
                cell.className = "checker-cell blank";
                cell.textContent = "";
              } else {
                cell.className = "checker-cell" + (drawnSet.has(value) ? " marked" : "");
                cell.textContent = value;
              }
              els.hostCheckerGrid.appendChild(cell);
            }
          }
        }

        let bingoCountdownTimer = null;

        function renderBingoNotice(claimPause) {
          if (bingoCountdownTimer) {
            clearInterval(bingoCountdownTimer);
            bingoCountdownTimer = null;
          }

          // Værten får resultatet i kontrolpanelet. Den store fuldskærmsbesked
          // er målrettet spillertelefonerne.
          if (isHost || !claimPause) {
            els.bingoNotice.classList.add("hidden");
            return;
          }

          els.bingoNotice.classList.remove("hidden");
          els.bingoNoticeCard.classList.remove("invalid", "valid");
          els.bingoCountdownWrap.classList.add("hidden");

          if (claimPause.status === "checking") {
            els.bingoNoticeTitle.textContent = "BANKO KALDT";
            els.bingoNoticeText.textContent = "Systemet kontrollerer pladerne…";
            return;
          }

          if (claimPause.status === "valid") {
            els.bingoNoticeCard.classList.add("valid");
            els.bingoNoticeTitle.textContent = "✅ BANKO GODKENDT";
            els.bingoNoticeText.textContent = "Der er Banko. Spillet er stoppet – vent på bartenderen.";
            return;
          }

          if (claimPause.status === "invalid") {
            els.bingoNoticeCard.classList.add("invalid");
            els.bingoNoticeTitle.textContent = "❌ DER VAR IKKE BANKO";
            els.bingoNoticeText.textContent = "Systemet har kontrolleret pladerne. Spillet fortsætter automatisk.";
            els.bingoCountdownWrap.classList.remove("hidden");

            const updateCountdown = () => {
              const ms = Math.max(0, Number(claimPause.endsAt || 0) - Date.now());
              const seconds = Math.max(0, Math.ceil(ms / 1000));
              els.bingoCountdown.textContent = String(seconds);
            };
            updateCountdown();
            bingoCountdownTimer = setInterval(updateCountdown, 200);
          }
        }

        function renderClaimResult(claim, targetEl, hostMode) {
          if (!claim) { targetEl.innerHTML = ""; return; }

          const summary = [];
          if (claim.fullBoard) summary.push("Fuld plade");
          if (claim.anyRow) summary.push("1 række");
          if (!summary.length) summary.push("Ingen gyldig række");

          const boardDetails = (claim.boardResults || []).map((res) => {
            const labels = [];
            if (res.fullBoard) labels.push("fuld plade");
            else if (res.hasAnyRow) labels.push(res.rowsCompleted + " række(r)");
            else labels.push("ingen række");
            return '<div class="result-item">Plade ' + (res.boardIndex + 1) + ': ' + labels.join(", ") + '</div>';
          }).join("");

          let boxClass = "claim info";
          if (claim.fullBoard || claim.anyRow) boxClass = "claim";
          if (!claim.valid) boxClass = "claim bad";

          const prefix = hostMode ? "Automatisk kontrol" : "Banko sendt";
          targetEl.innerHTML =
            '<div class="' + boxClass + '">' +
              '<strong>' + prefix + ': ' + claim.name + '</strong><br>' +
              'Resultat: ' + summary.join(" / ") + '<br>' +
              'Trukne tal: ' + claim.drawnCount +
              '<div class="result-list">' + boardDetails + '</div>' +
            '</div>';
        }

        function showBoardsOnlyMode() {
          els.playerLanding.classList.add("hidden");
          els.heroBox.classList.add("hidden");
          els.mainGrid.classList.remove("hidden");
          els.playerView.classList.remove("panel");
          els.playerView.style.background = "transparent";
          els.playerView.style.boxShadow = "none";
          els.playerView.style.padding = "0";
          els.mainGrid.style.display = "block";
        }

        socket.on("player:boards", ({ boards, approved, lastNumber, showBingoButton, showLastNumberOnPlayer }) => {
          if (isHost) return;
          if (!approved) { showWaitingMode(); return; }

          els.waitingBox.classList.add("hidden");
          els.playerBox.classList.remove("hidden");
          renderBoards(boards);
          showBoardsOnlyMode();

          if (showBingoButton) els.bingoBtn.classList.remove("hidden");
          else els.bingoBtn.classList.add("hidden");

          if (showLastNumberOnPlayer) {
            els.lastNumberPlayerBox.classList.remove("hidden");
            els.lastNumberPlayerBox.textContent = lastNumber || "-";
          } else {
            els.lastNumberPlayerBox.classList.add("hidden");
          }
        });

        socket.on("state:update", ({ drawn, lastNumber, remaining, playerCount, players, showBingoButton, showLastNumberOnPlayer, lastClaim, autoDrawEnabled, autoDrawSeconds, claimPause }) => {
          els.lastNumber.textContent = lastNumber || "-";
          els.drawnCount.textContent = drawn.length;
          els.remainingCount.textContent = remaining;
          els.playerCount.textContent = playerCount;
          els.drawnList.innerHTML = drawn.slice().reverse().map((n, idx) => '<span class="drawn-pill' + (idx === 0 ? ' latest' : '') + '">' + n + '</span>').join("");
          renderPlayerAdmin(players || []);
          renderHostChecker(drawn || []);
          renderBingoNotice(claimPause);

          if (isHost) {
            els.toggleBingo.checked = !!showBingoButton;
            els.toggleLastNumber.checked = !!showLastNumberOnPlayer;
            els.autoDrawSeconds.value = String(autoDrawSeconds === 20 ? 20 : 10);
            els.autoDrawBtn.dataset.running = autoDrawEnabled ? "1" : "0";
            els.autoDrawBtn.textContent = autoDrawEnabled ? "Stop auto-træk" : "Start auto-træk";
            els.autoDrawBtn.classList.toggle("danger", !!autoDrawEnabled);
            els.autoDrawStatus.textContent = autoDrawEnabled
              ? "Auto-træk kører hvert " + autoDrawSeconds + ". sekund"
              : "Auto-træk er slået fra";
            renderClaimResult(lastClaim, els.hostClaimBox, true);
          } else {
            if (showBingoButton) els.bingoBtn.classList.remove("hidden");
            else els.bingoBtn.classList.add("hidden");

            if (showLastNumberOnPlayer) {
              els.lastNumberPlayerBox.classList.remove("hidden");
              els.lastNumberPlayerBox.textContent = lastNumber || "-";
            } else {
              els.lastNumberPlayerBox.classList.add("hidden");
            }
          }
        });

        socket.on("bingo:claim", (claim) => {
          if (isHost) renderClaimResult(claim, els.hostClaimBox, true);
          else renderClaimResult(claim, els.claimBox, false);
        });

        const savedName = localStorage.getItem("pubbanko_name");
        if (savedName && !isHost) els.nameInput.value = savedName;

        renderHostChecker([]);
        recalcPrizeCalculator();
      </script>
    </body>
  </html>`;
}

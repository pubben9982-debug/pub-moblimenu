PUBBANKO UNLIMITED - LINUX TESTVERSION

Denne version er til Linux og indeholder:
- klassiske 90-tals Banko-plader
- bartender/host-side
- spillertelefoner via Socket.IO
- auto-træk hvert 10. eller 20. sekund
- serverstyret BANKO-kontrol
- tydelig spillerbesked ved BANKO
- ved forkert BANKO: fuldskærmsbesked på spillertelefoner + 10 sekunders nedtælling
- efter nedtællingen trækkes næste tal automatisk
- hvis auto-træk kørte før meldingen, fortsætter det bagefter med samme interval
- ved gyldig BANKO stoppes trækningen og spillerne bedes vente på bartenderen

VIGTIGT:
Dette er en testversion. Betaling, klip og præmier skal ikke aktiveres, før den konkrete model og nødvendige tilladelser er afklaret.
Se BARTENDER_REGLER.md.

Start:
  chmod +x setup.sh
  ./setup.sh

Spiller:
  http://DIN-IP:3000

Bartender/host:
  http://DIN-IP:3000/?host=1

#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"

echo
echo "=== Pubbanko Unlimited - Linux setup ==="
echo

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js er ikke installeret."
  echo "Installer Node.js og npm og koer setup.sh igen."
  exit 1
fi

if ! command -v npm >/dev/null 2>&1; then
  echo "npm er ikke installeret."
  echo "Installer npm og koer setup.sh igen."
  exit 1
fi

echo "Kontrollerer server.js..."
node --check server.js

echo "Installerer pakker..."
npm install

echo
echo "Starter Pubbanko..."
echo "Spiller: http://DIN-IP:3000"
echo "Host:    http://DIN-IP:3000/?host=1"
echo
exec npm start
